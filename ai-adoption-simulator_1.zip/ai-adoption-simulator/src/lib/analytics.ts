/**
 * Analytics abstraction layer.
 * Swap the internals for any analytics provider:
 * Posthog, Mixpanel, Segment, GA4, Amplitude, etc.
 *
 * Usage:
 *   import { track } from '@/lib/analytics'
 *   track('assessment_started')
 *   track('question_answered', { questionId: 3, profile: 'Explorer' })
 */

import { ProfileType } from '@/config/questions'
import { Scores } from './scoring'

type EventName =
  | 'assessment_started'
  | 'question_answered'
  | 'assessment_completed'
  | 'lead_captured'
  | 'result_viewed'
  | 'cta_clicked'
  | 'assessment_restarted'

type EventProperties = Record<string, string | number | boolean | null>

/**
 * Core tracking function. Add your analytics provider calls here.
 */
export function track(event: EventName, properties?: EventProperties): void {
  if (process.env.NODE_ENV === 'development') {
    console.log('[Analytics]', event, properties ?? '')
  }

  // ── Posthog ──────────────────────────────────────────────────────────────
  // if (typeof window !== 'undefined' && (window as any).posthog) {
  //   (window as any).posthog.capture(event, properties)
  // }

  // ── Segment ──────────────────────────────────────────────────────────────
  // if (typeof window !== 'undefined' && (window as any).analytics) {
  //   (window as any).analytics.track(event, properties)
  // }

  // ── GA4 ──────────────────────────────────────────────────────────────────
  // if (typeof window !== 'undefined' && (window as any).gtag) {
  //   (window as any).gtag('event', event, properties)
  // }
}

// ── Typed helpers ─────────────────────────────────────────────────────────────

export function trackAssessmentStarted() {
  track('assessment_started')
}

export function trackQuestionAnswered(questionId: number, profile: ProfileType) {
  track('question_answered', { questionId, profile })
}

export function trackAssessmentCompleted(scores: Scores) {
  track('assessment_completed', { ...scores })
}

export function trackLeadCaptured(role: string) {
  track('lead_captured', { role })
}

export function trackResultViewed(profile: ProfileType) {
  track('result_viewed', { profile })
}

export function trackCTAClicked(profile: ProfileType) {
  track('cta_clicked', { profile })
}

export function trackRestarted() {
  track('assessment_restarted')
}

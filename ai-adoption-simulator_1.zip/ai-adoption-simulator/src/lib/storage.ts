import { ProfileType } from '@/config/questions'
import { Scores } from './scoring'

export const STORAGE_KEY = 'ai_adoption_result'

export interface StoredResult {
  profile: ProfileType
  scores: Scores
  name: string
  email: string
  role: string
  answers: number[]
  completedAt: string
}

export function saveResult(result: StoredResult): void {
  try {
    localStorage.setItem(STORAGE_KEY, JSON.stringify(result))
  } catch (e) {
    console.warn('Could not save result to localStorage:', e)
  }
}

export function loadResult(): StoredResult | null {
  try {
    const raw = localStorage.getItem(STORAGE_KEY)
    return raw ? (JSON.parse(raw) as StoredResult) : null
  } catch (e) {
    console.warn('Could not load result from localStorage:', e)
    return null
  }
}

export function clearResult(): void {
  try {
    localStorage.removeItem(STORAGE_KEY)
  } catch (e) {
    console.warn('Could not clear result from localStorage:', e)
  }
}

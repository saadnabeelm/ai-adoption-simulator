import { ProfileType } from '@/config/questions'

export type Scores = Record<ProfileType, number>

export const INITIAL_SCORES: Scores = {
  Explorer: 0,
  Operator: 0,
  Overwhelmed: 0,
  Skeptic: 0,
}

/**
 * Calculates the dominant profile from a scores object.
 * Tie-break order: Overwhelmed → Operator → Explorer → Skeptic
 */
export function calculateDominantProfile(scores: Scores): ProfileType {
  const TIE_BREAK_ORDER: ProfileType[] = ['Overwhelmed', 'Operator', 'Explorer', 'Skeptic']
  const maxScore = Math.max(...Object.values(scores))
  return TIE_BREAK_ORDER.find((profile) => scores[profile] === maxScore)!
}

/**
 * Adds 2 points to the given profile in a scores object.
 * Returns a new scores object (immutable).
 */
export function addScore(scores: Scores, profile: ProfileType): Scores {
  return { ...scores, [profile]: scores[profile] + 2 }
}

/**
 * Subtracts 2 points from the given profile in a scores object.
 * Returns a new scores object (immutable).
 */
export function removeScore(scores: Scores, profile: ProfileType): Scores {
  return { ...scores, [profile]: Math.max(0, scores[profile] - 2) }
}

/**
 * Calculates the percentage share for each profile.
 * Useful for displaying score breakdowns.
 */
export function getScorePercentages(scores: Scores): Record<ProfileType, number> {
  const total = Object.values(scores).reduce((a, b) => a + b, 0)
  if (total === 0) return { Explorer: 0, Operator: 0, Overwhelmed: 0, Skeptic: 0 }
  return {
    Explorer: Math.round((scores.Explorer / total) * 100),
    Operator: Math.round((scores.Operator / total) * 100),
    Overwhelmed: Math.round((scores.Overwhelmed / total) * 100),
    Skeptic: Math.round((scores.Skeptic / total) * 100),
  }
}

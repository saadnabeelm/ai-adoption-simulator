/**
 * PDF Export utility.
 *
 * Two approaches provided:
 * 1. Browser print (zero deps, works immediately)
 * 2. jsPDF (rich formatting, install: npm i jspdf html2canvas)
 */

import { ProfileType } from '@/config/questions'
import { PROFILES } from '@/config/profiles'
import { Scores } from './scoring'

interface ExportData {
  profile: ProfileType
  scores: Scores
  name: string
  role: string
  completedAt: string
}

/**
 * Approach 1: Browser print dialog (zero dependencies)
 * Triggers the browser's native print → Save as PDF flow.
 * Style the print layout with @media print in globals.css.
 */
export function printResultsPage(): void {
  window.print()
}

/**
 * Approach 2: Programmatic PDF with jsPDF
 * Install: npm install jspdf html2canvas
 * Uncomment and use when you need a richer, controlled PDF output.
 */
export async function exportToPDF(data: ExportData): Promise<void> {
  // Dynamically import to avoid bundle bloat when not used
  // const { default: jsPDF } = await import('jspdf')
  // const { default: html2canvas } = await import('html2canvas')

  const p = PROFILES[data.profile]
  const dateStr = new Date(data.completedAt).toLocaleDateString('en-GB', {
    day: 'numeric',
    month: 'long',
    year: 'numeric',
  })

  // ── jsPDF example ──────────────────────────────────────────────────────
  // const doc = new jsPDF({ unit: 'mm', format: 'a4' })
  // doc.setFontSize(28)
  // doc.text('AI Adoption Simulator', 20, 30)
  // doc.setFontSize(14)
  // doc.text(`${data.name} — ${data.role}`, 20, 45)
  // doc.setFontSize(22)
  // doc.text(data.profile, 20, 65)
  // doc.setFontSize(11)
  // doc.text(p.summary, 20, 80, { maxWidth: 170 })
  // doc.setFontSize(13)
  // doc.text('Your Description', 20, 105)
  // doc.setFontSize(10)
  // doc.text(p.description, 20, 115, { maxWidth: 170 })
  // doc.setFontSize(13)
  // doc.text('Recommended Next Step', 20, 160)
  // doc.setFontSize(10)
  // doc.text(p.nextStep, 20, 170, { maxWidth: 170 })
  // doc.setFontSize(9)
  // doc.text(`Generated ${dateStr}`, 20, 280)
  // doc.save(`ai-work-style-${data.profile.toLowerCase()}-${data.name.replace(' ', '-')}.pdf`)

  // Fallback: print
  printResultsPage()
}

/**
 * Approach 3: html2canvas screenshot of the results DOM node
 * Captures the rendered HTML exactly as shown on screen.
 */
export async function exportResultsAsImage(elementId: string, filename: string): Promise<void> {
  // const { default: html2canvas } = await import('html2canvas')
  // const element = document.getElementById(elementId)
  // if (!element) return
  // const canvas = await html2canvas(element, { scale: 2, useCORS: true })
  // const link = document.createElement('a')
  // link.download = `${filename}.png`
  // link.href = canvas.toDataURL('image/png')
  // link.click()
  console.log('Export as image — install html2canvas and uncomment above')
}

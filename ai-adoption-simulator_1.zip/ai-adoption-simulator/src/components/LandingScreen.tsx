'use client'

import { motion } from 'framer-motion'

interface LandingScreenProps {
  onStart: () => void
}

const highlights = [
  { color: '#2D5BE3', label: '12 questions', sub: 'Takes about 4 minutes' },
  { color: '#0F6E56', label: '4 profiles', sub: 'Personalised result' },
  { color: '#BA7517', label: 'Actionable', sub: 'Clear next steps' },
  { color: '#993556', label: 'B2B ready', sub: 'Built for teams' },
]

export default function LandingScreen({ onStart }: LandingScreenProps) {
  return (
    <motion.div
      className="flex flex-col items-center justify-center min-h-screen px-4 py-16"
      initial={{ opacity: 0, y: 20 }}
      animate={{ opacity: 1, y: 0 }}
      transition={{ duration: 0.5 }}
    >
      <div className="w-full max-w-2xl text-center">
        <motion.div
          className="inline-flex items-center gap-2 bg-accent-soft text-accent text-xs font-semibold tracking-widest uppercase px-4 py-1.5 rounded-full mb-8"
          initial={{ opacity: 0, scale: 0.9 }}
          animate={{ opacity: 1, scale: 1 }}
          transition={{ delay: 0.1 }}
        >
          <svg width="12" height="12" viewBox="0 0 12 12" fill="none">
            <circle cx="6" cy="6" r="5" stroke="currentColor" strokeWidth="1.5" />
            <path d="M6 3.5v2.5l1.5 1" stroke="currentColor" strokeWidth="1.5" strokeLinecap="round" />
          </svg>
          Workplace Assessment
        </motion.div>

        <motion.h1
          className="font-serif text-5xl md:text-6xl leading-[1.12] mb-5"
          initial={{ opacity: 0, y: 16 }}
          animate={{ opacity: 1, y: 0 }}
          transition={{ delay: 0.2 }}
        >
          Discover Your<br />
          <em>AI Work Style</em>
        </motion.h1>

        <motion.p
          className="text-lg text-muted leading-relaxed max-w-md mx-auto mb-10"
          initial={{ opacity: 0 }}
          animate={{ opacity: 1 }}
          transition={{ delay: 0.3 }}
        >
          Understand how you actually use AI at work — and how to level up your practice with confidence.
        </motion.p>

        <motion.button
          onClick={onStart}
          className="inline-flex items-center gap-3 bg-[#1A1814] text-white font-medium text-base px-8 py-4 rounded-full transition-all hover:-translate-y-0.5 hover:shadow-xl active:translate-y-0"
          initial={{ opacity: 0, y: 10 }}
          animate={{ opacity: 1, y: 0 }}
          transition={{ delay: 0.4 }}
          whileHover={{ scale: 1.02 }}
          whileTap={{ scale: 0.98 }}
        >
          Start Assessment
          <svg width="16" height="16" viewBox="0 0 16 16" fill="none">
            <path d="M3 8h10M9 4l4 4-4 4" stroke="currentColor" strokeWidth="1.5" strokeLinecap="round" strokeLinejoin="round" />
          </svg>
        </motion.button>

        <motion.div
          className="grid grid-cols-2 md:grid-cols-4 gap-3 mt-12"
          initial={{ opacity: 0 }}
          animate={{ opacity: 1 }}
          transition={{ delay: 0.5 }}
        >
          {highlights.map((h) => (
            <div key={h.label} className="bg-surface border border-border rounded-2xl p-4 flex items-start gap-3 text-left">
              <div className="w-2.5 h-2.5 rounded-full mt-1 flex-shrink-0" style={{ background: h.color }} />
              <div>
                <p className="text-sm font-medium text-[#1A1814]">{h.label}</p>
                <p className="text-xs text-muted mt-0.5">{h.sub}</p>
              </div>
            </div>
          ))}
        </motion.div>
      </div>
    </motion.div>
  )
}

'use client'

import { useState } from 'react'
import { motion } from 'framer-motion'
import { UserInfo } from '@/hooks/useAssessment'

interface LeadCaptureScreenProps {
  onSubmit: (info: UserInfo) => void
}

export default function LeadCaptureScreen({ onSubmit }: LeadCaptureScreenProps) {
  const [name, setName] = useState('')
  const [email, setEmail] = useState('')
  const [role, setRole] = useState('')
  const [errors, setErrors] = useState<Partial<Record<'name' | 'email' | 'role', string>>>({})

  const validate = () => {
    const e: typeof errors = {}
    if (!name.trim()) e.name = 'Please enter your name'
    if (!email.trim() || !email.includes('@')) e.email = 'Please enter a valid email'
    if (!role.trim()) e.role = 'Please enter your role'
    setErrors(e)
    return Object.keys(e).length === 0
  }

  const handleSubmit = () => {
    if (!validate()) return
    onSubmit({ name: name.trim(), email: email.trim(), role: role.trim() })
  }

  return (
    <div className="min-h-screen flex items-center justify-center px-4 py-16">
      <motion.div
        className="w-full max-w-md bg-surface border border-border rounded-3xl p-8 md:p-10"
        initial={{ opacity: 0, y: 24 }}
        animate={{ opacity: 1, y: 0 }}
        transition={{ duration: 0.5 }}
      >
        <div className="text-2xl mb-4">✦</div>
        <h2 className="font-serif text-3xl mb-2">Your profile is ready</h2>
        <p className="text-muted text-[0.9375rem] leading-relaxed mb-8">
          Enter your details below to unlock your personalised AI work style result.
        </p>

        <div className="flex flex-col gap-5">
          <div>
            <label className="block text-sm font-medium mb-1.5">Full name</label>
            <input
              type="text"
              value={name}
              onChange={(e) => setName(e.target.value)}
              placeholder="Your name"
              className="w-full bg-surface2 border-[1.5px] border-border rounded-xl px-4 py-3 text-[0.9375rem] text-[#1A1814] outline-none transition-colors focus:border-[#1A1814] placeholder:text-[#a8a49f]"
            />
            {errors.name && <p className="text-red-500 text-xs mt-1">{errors.name}</p>}
          </div>

          <div>
            <label className="block text-sm font-medium mb-1.5">Work email</label>
            <input
              type="email"
              value={email}
              onChange={(e) => setEmail(e.target.value)}
              placeholder="you@company.com"
              className="w-full bg-surface2 border-[1.5px] border-border rounded-xl px-4 py-3 text-[0.9375rem] text-[#1A1814] outline-none transition-colors focus:border-[#1A1814] placeholder:text-[#a8a49f]"
            />
            {errors.email && <p className="text-red-500 text-xs mt-1">{errors.email}</p>}
          </div>

          <div>
            <label className="block text-sm font-medium mb-1.5">Role / Job title</label>
            <input
              type="text"
              value={role}
              onChange={(e) => setRole(e.target.value)}
              placeholder="e.g. Marketing Manager"
              className="w-full bg-surface2 border-[1.5px] border-border rounded-xl px-4 py-3 text-[0.9375rem] text-[#1A1814] outline-none transition-colors focus:border-[#1A1814] placeholder:text-[#a8a49f]"
            />
            {errors.role && <p className="text-red-500 text-xs mt-1">{errors.role}</p>}
          </div>
        </div>

        <button
          onClick={handleSubmit}
          className="w-full mt-6 bg-[#1A1814] text-white font-medium text-base py-4 rounded-full flex items-center justify-center gap-3 transition-all hover:-translate-y-0.5 hover:shadow-xl active:translate-y-0"
        >
          View My Profile
          <svg width="16" height="16" viewBox="0 0 16 16" fill="none">
            <path d="M3 8h10M9 4l4 4-4 4" stroke="currentColor" strokeWidth="1.5" strokeLinecap="round" strokeLinejoin="round" />
          </svg>
        </button>

        <p className="text-xs text-muted text-center mt-4">
          No spam. Your data is used only to personalise your results.
        </p>
      </motion.div>
    </div>
  )
}

'use client'

import { motion, AnimatePresence } from 'framer-motion'
import { Question } from '@/config/questions'
import ProgressBar from './ProgressBar'

interface AssessmentScreenProps {
  question: Question
  questionIndex: number
  totalQuestions: number
  progress: number
  selectedAnswer: number | null
  onSelect: (index: number) => void
  onNext: () => void
  onBack: () => void
}

const LETTERS = ['A', 'B', 'C', 'D']

export default function AssessmentScreen({
  question,
  questionIndex,
  totalQuestions,
  progress,
  selectedAnswer,
  onSelect,
  onNext,
  onBack,
}: AssessmentScreenProps) {
  return (
    <div className="min-h-screen flex flex-col items-center pt-20 px-4 pb-12">
      <ProgressBar current={questionIndex} total={totalQuestions} percent={progress} onBack={onBack} />

      <AnimatePresence mode="wait">
        <motion.div
          key={questionIndex}
          className="w-full max-w-xl pt-8"
          initial={{ opacity: 0, x: 30 }}
          animate={{ opacity: 1, x: 0 }}
          exit={{ opacity: 0, x: -20 }}
          transition={{ duration: 0.3, ease: 'easeOut' }}
        >
          <p className="text-xs font-semibold tracking-widest uppercase text-muted mb-3">
            Question {questionIndex + 1} of {totalQuestions}
          </p>

          <h2 className="font-serif text-2xl md:text-3xl leading-snug mb-8 text-[#1A1814]">
            {question.question}
          </h2>

          <div className="flex flex-col gap-3 mb-8">
            {question.answers.map((answer, idx) => {
              const isSelected = selectedAnswer === idx
              return (
                <motion.button
                  key={idx}
                  onClick={() => onSelect(idx)}
                  className={`w-full text-left flex items-center gap-4 p-4 rounded-2xl border-[1.5px] transition-all ${
                    isSelected
                      ? 'border-[#1A1814] bg-[#1A1814] text-white'
                      : 'border-border bg-surface hover:border-[#b0aaa0] hover:-translate-y-px hover:shadow-md'
                  }`}
                  whileTap={{ scale: 0.99 }}
                >
                  <div
                    className={`w-7 h-7 rounded-lg flex items-center justify-center text-xs font-semibold flex-shrink-0 border transition-all ${
                      isSelected
                        ? 'bg-white/15 text-white border-white/30'
                        : 'bg-surface2 text-muted border-border'
                    }`}
                  >
                    {LETTERS[idx]}
                  </div>
                  <span className={`text-[0.9375rem] leading-snug ${isSelected ? 'text-white' : 'text-[#1A1814]'}`}>
                    {answer.text}
                  </span>
                </motion.button>
              )
            })}
          </div>

          <div className="flex justify-end">
            <button
              onClick={onNext}
              disabled={selectedAnswer === null}
              className="inline-flex items-center gap-2 bg-[#1A1814] text-white font-medium text-[0.9375rem] px-7 py-3.5 rounded-full transition-all hover:-translate-y-px hover:shadow-lg disabled:opacity-30 disabled:cursor-not-allowed disabled:translate-y-0 disabled:shadow-none"
            >
              {questionIndex === totalQuestions - 1 ? 'See My Results' : 'Continue'}
              <svg width="16" height="16" viewBox="0 0 16 16" fill="none">
                <path d="M3 8h10M9 4l4 4-4 4" stroke="currentColor" strokeWidth="1.5" strokeLinecap="round" strokeLinejoin="round" />
              </svg>
            </button>
          </div>
        </motion.div>
      </AnimatePresence>
    </div>
  )
}

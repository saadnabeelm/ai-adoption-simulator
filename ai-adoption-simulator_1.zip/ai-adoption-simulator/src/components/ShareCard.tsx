'use client'

import { motion } from 'framer-motion'
import { ProfileType } from '@/config/questions'
import { PROFILES } from '@/config/profiles'

interface ShareCardProps {
  profile: ProfileType
  name?: string
}

/**
 * A self-contained shareable card.
 * Can be screenshotted or rendered server-side for OG images.
 * Future: connect to /api/og route for dynamic OG image generation.
 */
export default function ShareCard({ profile, name }: ShareCardProps) {
  const p = PROFILES[profile]
  const displayName = name ? name.split(' ')[0] : null

  const handleShare = async () => {
    const text = `I just discovered I'm ${profile === 'Operator' || profile === 'Overwhelmed' ? 'an' : 'a'} ${profile} on the AI Adoption Simulator. ${p.ctaLine}`
    const url = window.location.href

    if (navigator.share) {
      try {
        await navigator.share({ title: 'My AI Work Style', text, url })
      } catch {
        // User cancelled share
      }
    } else {
      await navigator.clipboard.writeText(`${text}\n\n${url}`)
      alert('Link copied to clipboard!')
    }
  }

  return (
    <motion.div
      className="rounded-2xl p-6 border flex flex-col gap-3"
      style={{ background: p.bgColor, borderColor: p.color + '33' }}
      initial={{ opacity: 0 }}
      animate={{ opacity: 1 }}
      transition={{ delay: 0.6 }}
    >
      <div className="flex items-center justify-between">
        <span className="text-xs font-semibold tracking-widest uppercase" style={{ color: p.color }}>
          Share your result
        </span>
        <button
          onClick={handleShare}
          className="inline-flex items-center gap-2 px-4 py-2 rounded-full text-xs font-semibold transition-all hover:opacity-80"
          style={{ background: p.color, color: 'white' }}
        >
          <svg width="14" height="14" viewBox="0 0 14 14" fill="none">
            <path d="M10 4.667a1.667 1.667 0 1 0 0-3.334 1.667 1.667 0 0 0 0 3.334ZM4 7.667a1.667 1.667 0 1 0 0-3.334 1.667 1.667 0 0 0 0 3.334ZM10 10.667a1.667 1.667 0 1 0 0-3.334 1.667 1.667 0 0 0 0 3.334ZM5.617 6.833l2.773 1.617M8.383 5.55 5.617 7.167" stroke="currentColor" strokeWidth="1.2" strokeLinecap="round" />
          </svg>
          Share
        </button>
      </div>
      <p className="text-sm leading-relaxed" style={{ color: p.textColor }}>
        {displayName ? `${displayName} is` : "I'm"}{' '}
        {profile === 'Operator' || profile === 'Overwhelmed' ? 'an' : 'a'}{' '}
        <strong>{profile}</strong> — {p.theme.toLowerCase()}.
      </p>
    </motion.div>
  )
}

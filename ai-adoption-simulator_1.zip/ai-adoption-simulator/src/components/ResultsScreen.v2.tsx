'use client'

import { useEffect } from 'react'
import { motion } from 'framer-motion'
import { ProfileType } from '@/config/questions'
import { PROFILES } from '@/config/profiles'
import { Scores, getScorePercentages } from '@/lib/scoring'
import { trackResultViewed, trackCTAClicked, trackRestarted } from '@/lib/analytics'
import { printResultsPage } from '@/lib/export'
import ShareCard from './ShareCard'

interface ResultsScreenProps {
  profile: ProfileType
  scores: Scores
  name: string
  role: string
  completedAt: string
  onRestart: () => void
}

const PROFILE_ORDER: ProfileType[] = ['Explorer', 'Operator', 'Overwhelmed', 'Skeptic']

export default function ResultsScreen({
  profile,
  scores,
  name,
  role,
  completedAt,
  onRestart,
}: ResultsScreenProps) {
  const p = PROFILES[profile]
  const percentages = getScorePercentages(scores)
  const displayName = name || 'You'
  const isYou = displayName === 'You'
  const article = profile === 'Operator' || profile === 'Overwhelmed' ? 'an' : 'a'

  useEffect(() => {
    trackResultViewed(profile)
  }, [profile])

  const handleCTA = () => {
    trackCTAClicked(profile)
    // Connect to your upgrade plan flow here
    alert('This connects to your personalised AI Upgrade Plan — wire up to your CRM or booking link.')
  }

  const handleRestart = () => {
    trackRestarted()
    onRestart()
  }

  return (
    <div id="results-page" className="min-h-screen flex flex-col items-center px-4 py-16">
      <motion.div
        className="w-full max-w-2xl"
        initial={{ opacity: 0, y: 24 }}
        animate={{ opacity: 1, y: 0 }}
        transition={{ duration: 0.5 }}
      >
        {/* Profile badge */}
        <motion.div
          className="inline-flex items-center gap-2 px-5 py-2 rounded-full text-xs font-semibold tracking-widest uppercase mb-6"
          style={{ background: p.bgColor, color: p.color }}
          initial={{ opacity: 0, scale: 0.9 }}
          animate={{ opacity: 1, scale: 1 }}
          transition={{ delay: 0.1 }}
        >
          ✦ {profile}
        </motion.div>

        <motion.h1
          className="font-serif text-4xl md:text-5xl leading-tight mb-4"
          initial={{ opacity: 0, y: 12 }}
          animate={{ opacity: 1, y: 0 }}
          transition={{ delay: 0.15 }}
        >
          {isYou ? 'You' : name}, you're {article}{' '}
          <em style={{ color: p.color }}>{profile}</em>
        </motion.h1>

        <motion.p
          className="text-lg text-muted leading-relaxed mb-8"
          initial={{ opacity: 0 }}
          animate={{ opacity: 1 }}
          transition={{ delay: 0.2 }}
        >
          {p.summary}
        </motion.p>

        {/* Description */}
        <motion.div
          className="bg-surface border border-border rounded-2xl p-6 mb-4"
          initial={{ opacity: 0, y: 12 }}
          animate={{ opacity: 1, y: 0 }}
          transition={{ delay: 0.25 }}
        >
          <p className="text-xs font-semibold tracking-widest uppercase text-muted mb-4">Your profile</p>
          <p className="text-[0.9375rem] leading-7 text-[#1A1814]">{p.description}</p>
        </motion.div>

        {/* Strengths + Challenges */}
        <motion.div
          className="grid grid-cols-1 md:grid-cols-2 gap-4 mb-4"
          initial={{ opacity: 0, y: 12 }}
          animate={{ opacity: 1, y: 0 }}
          transition={{ delay: 0.3 }}
        >
          <div className="bg-surface border border-border rounded-2xl p-6">
            <p className="text-xs font-semibold tracking-widest uppercase text-muted mb-4">Strengths</p>
            <ul className="flex flex-col gap-3">
              {p.strengths.map((s) => (
                <li key={s} className="flex items-start gap-2.5 text-sm leading-snug">
                  <span
                    className="w-5 h-5 rounded-full flex items-center justify-center text-[10px] flex-shrink-0 mt-0.5"
                    style={{ background: '#E1F5EE', color: '#0F6E56' }}
                  >
                    ✓
                  </span>
                  {s}
                </li>
              ))}
            </ul>
          </div>

          <div className="bg-surface border border-border rounded-2xl p-6">
            <p className="text-xs font-semibold tracking-widest uppercase text-muted mb-4">Challenges</p>
            <ul className="flex flex-col gap-3">
              {p.challenges.map((c) => (
                <li key={c} className="flex items-start gap-2.5 text-sm leading-snug">
                  <span
                    className="w-5 h-5 rounded-full flex items-center justify-center text-[10px] flex-shrink-0 mt-0.5"
                    style={{ background: '#FAEEDA', color: '#BA7517' }}
                  >
                    →
                  </span>
                  {c}
                </li>
              ))}
            </ul>
          </div>
        </motion.div>

        {/* Next step */}
        <motion.div
          className="rounded-2xl p-6 mb-4 border"
          style={{ background: p.bgColor, borderColor: p.color + '33' }}
          initial={{ opacity: 0, y: 12 }}
          animate={{ opacity: 1, y: 0 }}
          transition={{ delay: 0.35 }}
        >
          <p className="text-xs font-semibold tracking-widest uppercase mb-3" style={{ color: p.color }}>
            Recommended next step
          </p>
          <p className="text-[0.9375rem] font-medium leading-relaxed text-[#1A1814]">{p.nextStep}</p>
        </motion.div>

        {/* Score breakdown */}
        <motion.div
          className="bg-surface border border-border rounded-2xl p-6 mb-4"
          initial={{ opacity: 0, y: 12 }}
          animate={{ opacity: 1, y: 0 }}
          transition={{ delay: 0.4 }}
        >
          <p className="text-xs font-semibold tracking-widest uppercase text-muted mb-4">Score breakdown</p>
          <div className="flex flex-col gap-3">
            {[...PROFILE_ORDER]
              .sort((a, b) => scores[b] - scores[a])
              .map((profileKey, idx) => (
                <div key={profileKey} className="flex items-center gap-3">
                  <span className="text-xs font-medium text-muted w-24 flex-shrink-0">{profileKey}</span>
                  <div className="flex-1 h-1.5 bg-border rounded-full overflow-hidden">
                    <motion.div
                      className="h-full rounded-full"
                      style={{ background: PROFILES[profileKey].color }}
                      initial={{ width: 0 }}
                      animate={{ width: `${percentages[profileKey]}%` }}
                      transition={{ delay: 0.5 + idx * 0.08, duration: 0.7, ease: 'easeOut' }}
                    />
                  </div>
                  <span className="text-xs font-semibold text-muted w-7 text-right">{scores[profileKey]}</span>
                </div>
              ))}
          </div>
        </motion.div>

        {/* Share card */}
        <ShareCard profile={profile} name={name} />

        {/* CTA quote + button */}
        <motion.p
          className="font-serif text-xl italic text-center text-[#1A1814] my-8 leading-relaxed"
          initial={{ opacity: 0 }}
          animate={{ opacity: 1 }}
          transition={{ delay: 0.55 }}
        >
          "{p.ctaLine}"
        </motion.p>

        <motion.button
          onClick={handleCTA}
          className="w-full bg-[#1A1814] text-white font-medium text-base py-5 rounded-full flex items-center justify-center gap-3 transition-all hover:-translate-y-0.5 hover:shadow-xl mb-3"
          initial={{ opacity: 0, y: 12 }}
          animate={{ opacity: 1, y: 0 }}
          transition={{ delay: 0.6 }}
          whileTap={{ scale: 0.98 }}
        >
          Get Your Personalised AI Upgrade Plan
          <svg width="18" height="18" viewBox="0 0 18 18" fill="none">
            <path d="M3.75 9h10.5M10.5 5.25L14.25 9l-3.75 3.75" stroke="white" strokeWidth="1.5" strokeLinecap="round" strokeLinejoin="round" />
          </svg>
        </motion.button>

        {/* Secondary actions */}
        <div className="flex items-center justify-center gap-4 mt-2">
          <button
            onClick={printResultsPage}
            className="text-sm text-muted hover:text-[#1A1814] transition-colors flex items-center gap-1.5"
          >
            <svg width="14" height="14" viewBox="0 0 14 14" fill="none">
              <path d="M3.5 5V2.333h7V5M3.5 10.5H2.333A1.167 1.167 0 0 1 1.167 9.333V6.167A1.167 1.167 0 0 1 2.333 5h9.334a1.167 1.167 0 0 1 1.166 1.167v3.166a1.167 1.167 0 0 1-1.166 1.167H10.5M3.5 8.167h7V12.25h-7V8.167Z" stroke="currentColor" strokeWidth="1.1" strokeLinecap="round" strokeLinejoin="round" />
            </svg>
            Save as PDF
          </button>
          <span className="text-border">·</span>
          <button
            onClick={handleRestart}
            className="text-sm text-muted hover:text-[#1A1814] transition-colors"
          >
            Start over
          </button>
        </div>

        {/* Timestamp */}
        <p className="text-xs text-muted text-center mt-8">
          Completed {new Date(completedAt).toLocaleDateString('en-GB', { day: 'numeric', month: 'long', year: 'numeric' })}
        </p>
      </motion.div>
    </div>
  )
}

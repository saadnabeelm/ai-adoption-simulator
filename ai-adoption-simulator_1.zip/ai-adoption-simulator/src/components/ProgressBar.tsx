'use client'

import { motion } from 'framer-motion'

interface ProgressBarProps {
  current: number
  total: number
  percent: number
  onBack: () => void
}

const LETTERS = ['A', 'B', 'C', 'D']

export default function ProgressBar({ current, total, percent, onBack }: ProgressBarProps) {
  return (
    <div className="fixed top-0 left-0 right-0 z-50 px-6 py-4 bg-bg/90 backdrop-blur-sm border-b border-border flex items-center gap-4">
      <button
        onClick={onBack}
        disabled={current === 0}
        className="w-9 h-9 rounded-full border border-border flex items-center justify-center text-muted transition-all hover:bg-surface hover:text-[#1A1814] disabled:opacity-30 disabled:cursor-not-allowed"
      >
        <svg width="16" height="16" viewBox="0 0 16 16" fill="none">
          <path d="M10 3L5 8l5 5" stroke="currentColor" strokeWidth="1.5" strokeLinecap="round" strokeLinejoin="round" />
        </svg>
      </button>

      <div className="flex-1 h-1 bg-border rounded-full overflow-hidden">
        <motion.div
          className="h-full bg-[#1A1814] rounded-full"
          animate={{ width: `${percent}%` }}
          transition={{ duration: 0.4, ease: 'easeInOut' }}
        />
      </div>

      <span className="text-xs font-medium text-muted flex-shrink-0">
        {current + 1} / {total}
      </span>
    </div>
  )
}

import type { Metadata } from 'next'
import { DM_Sans, DM_Serif_Display } from 'next/font/google'
import './globals.css'

const dmSans = DM_Sans({
  subsets: ['latin'],
  variable: '--font-dm-sans',
  display: 'swap',
})

const dmSerifDisplay = DM_Serif_Display({
  subsets: ['latin'],
  weight: '400',
  style: ['normal', 'italic'],
  variable: '--font-dm-serif',
  display: 'swap',
})

export const metadata: Metadata = {
  title: 'AI Adoption Simulator — Discover Your AI Work Style',
  description:
    'Take a 4-minute workplace assessment to understand how you actually use AI at work — and get a personalised profile with clear next steps.',
  openGraph: {
    title: 'AI Adoption Simulator',
    description: 'Discover your AI work style in 12 questions.',
    type: 'website',
  },
}

export default function RootLayout({ children }: { children: React.ReactNode }) {
  return (
    <html lang="en" className={`${dmSans.variable} ${dmSerifDisplay.variable}`}>
      <body className="font-sans antialiased">{children}</body>
    </html>
  )
}

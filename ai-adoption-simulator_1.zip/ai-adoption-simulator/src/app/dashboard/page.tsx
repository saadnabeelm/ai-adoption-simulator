'use client'

import { useEffect, useState } from 'react'
import { motion } from 'framer-motion'
import { PROFILES } from '@/config/profiles'
import { ProfileType } from '@/config/questions'

interface DashboardData {
  total: number
  profiles: Record<ProfileType, number>
  completionRate: number
  averageTimeSeconds: number
  topRoles: string[]
  recentLeads: { name: string; role: string; profile: ProfileType; completedAt: string }[]
}

const PROFILE_ORDER: ProfileType[] = ['Operator', 'Explorer', 'Overwhelmed', 'Skeptic']

/**
 * Organisation dashboard — /dashboard
 * Protected by DASHBOARD_API_KEY in production.
 * Shows aggregate profile distribution, completion metrics, recent leads.
 */
export default function DashboardPage() {
  const [data, setData] = useState<DashboardData | null>(null)
  const [loading, setLoading] = useState(true)

  useEffect(() => {
    fetch('/api/results')
      .then((r) => r.json())
      .then((d) => { setData(d); setLoading(false) })
      .catch(() => setLoading(false))
  }, [])

  if (loading) {
    return (
      <div className="min-h-screen bg-bg flex items-center justify-center">
        <div className="text-muted text-sm">Loading dashboard…</div>
      </div>
    )
  }

  if (!data) {
    return (
      <div className="min-h-screen bg-bg flex items-center justify-center">
        <div className="text-muted text-sm">Could not load dashboard data.</div>
      </div>
    )
  }

  const total = data.total || 1

  return (
    <div className="min-h-screen bg-bg px-6 py-12">
      <div className="max-w-5xl mx-auto">

        {/* Header */}
        <div className="mb-10">
          <div className="inline-flex items-center gap-2 bg-accent-soft text-accent text-xs font-semibold tracking-widest uppercase px-4 py-1.5 rounded-full mb-4">
            Organisation Dashboard
          </div>
          <h1 className="font-serif text-4xl mb-2">AI Adoption Overview</h1>
          <p className="text-muted">Aggregated results across your organisation.</p>
        </div>

        {/* Summary metrics */}
        <div className="grid grid-cols-2 md:grid-cols-4 gap-4 mb-8">
          {[
            { label: 'Total completed', value: data.total.toLocaleString() },
            { label: 'Completion rate', value: `${Math.round(data.completionRate * 100)}%` },
            { label: 'Avg time', value: `${Math.round(data.averageTimeSeconds / 60)}m ${data.averageTimeSeconds % 60}s` },
            { label: 'Top profile', value: PROFILE_ORDER.sort((a, b) => data.profiles[b] - data.profiles[a])[0] },
          ].map((m) => (
            <div key={m.label} className="bg-surface border border-border rounded-2xl p-5">
              <p className="text-xs text-muted mb-1 font-medium">{m.label}</p>
              <p className="font-serif text-2xl text-[#1A1814]">{m.value}</p>
            </div>
          ))}
        </div>

        {/* Profile breakdown */}
        <div className="bg-surface border border-border rounded-2xl p-6 mb-6">
          <h2 className="font-serif text-xl mb-6">Profile distribution</h2>
          <div className="flex flex-col gap-5">
            {PROFILE_ORDER.sort((a, b) => data.profiles[b] - data.profiles[a]).map((profile, idx) => {
              const count = data.profiles[profile]
              const pct = Math.round((count / total) * 100)
              const p = PROFILES[profile]
              return (
                <motion.div
                  key={profile}
                  initial={{ opacity: 0, y: 8 }}
                  animate={{ opacity: 1, y: 0 }}
                  transition={{ delay: idx * 0.08 }}
                >
                  <div className="flex items-center justify-between mb-2">
                    <div className="flex items-center gap-3">
                      <span
                        className="inline-flex items-center px-3 py-1 rounded-full text-xs font-semibold"
                        style={{ background: p.bgColor, color: p.color }}
                      >
                        {profile}
                      </span>
                      <span className="text-sm text-muted">{p.theme}</span>
                    </div>
                    <div className="text-right">
                      <span className="text-sm font-semibold text-[#1A1814]">{count}</span>
                      <span className="text-sm text-muted ml-1">({pct}%)</span>
                    </div>
                  </div>
                  <div className="h-2 bg-border rounded-full overflow-hidden">
                    <motion.div
                      className="h-full rounded-full"
                      style={{ background: p.color }}
                      initial={{ width: 0 }}
                      animate={{ width: `${pct}%` }}
                      transition={{ delay: 0.3 + idx * 0.1, duration: 0.8, ease: 'easeOut' }}
                    />
                  </div>
                </motion.div>
              )
            })}
          </div>
        </div>

        {/* Top roles + recent leads */}
        <div className="grid grid-cols-1 md:grid-cols-2 gap-6">
          <div className="bg-surface border border-border rounded-2xl p-6">
            <h2 className="font-serif text-xl mb-4">Top roles</h2>
            <ul className="flex flex-col gap-3">
              {data.topRoles.map((role, i) => (
                <li key={role} className="flex items-center gap-3 text-sm">
                  <span className="w-6 h-6 rounded-full bg-surface2 text-muted text-xs flex items-center justify-center font-semibold flex-shrink-0">
                    {i + 1}
                  </span>
                  {role}
                </li>
              ))}
            </ul>
          </div>

          <div className="bg-surface border border-border rounded-2xl p-6">
            <h2 className="font-serif text-xl mb-4">Recent completions</h2>
            <ul className="flex flex-col gap-3">
              {data.recentLeads.map((lead, i) => {
                const p = PROFILES[lead.profile]
                return (
                  <li key={i} className="flex items-center justify-between text-sm">
                    <div>
                      <span className="font-medium text-[#1A1814]">{lead.name}</span>
                      <span className="text-muted ml-1.5">· {lead.role}</span>
                    </div>
                    <span
                      className="px-2.5 py-1 rounded-full text-xs font-semibold flex-shrink-0"
                      style={{ background: p.bgColor, color: p.color }}
                    >
                      {lead.profile}
                    </span>
                  </li>
                )
              })}
            </ul>
          </div>
        </div>

        <p className="text-xs text-muted text-center mt-10">
          Data refreshes on page load. Connect a real database in <code className="bg-surface2 px-1.5 py-0.5 rounded">/api/results</code> for live updates.
        </p>
      </div>
    </div>
  )
}

'use client'

import { AnimatePresence } from 'framer-motion'
import { useAssessment } from '@/hooks/useAssessment'
import LandingScreen from '@/components/LandingScreen'
import AssessmentScreen from '@/components/AssessmentScreen'
import LeadCaptureScreen from '@/components/LeadCaptureScreen'
import ResultsScreen from '@/components/ResultsScreen'
import { PROFILES } from '@/config/profiles'

export default function Home() {
  const {
    screen,
    currentQuestion,
    totalQuestions,
    progress,
    currentQuestionData,
    currentAnswerIndex,
    scores,
    profile,
    userInfo,
    start,
    selectAnswer,
    next,
    back,
    submitLead,
    restart,
  } = useAssessment()

  const bgColor =
    screen === 'results' && profile
      ? PROFILES[profile].bgColor + '40'
      : '#F7F5F0'

  return (
    <main
      className="min-h-screen transition-colors duration-700"
      style={{ background: screen === 'results' && profile ? `linear-gradient(180deg, ${PROFILES[profile].bgColor}60 0%, #F7F5F0 400px)` : '#F7F5F0' }}
    >
      <AnimatePresence mode="wait">
        {screen === 'landing' && (
          <LandingScreen key="landing" onStart={start} />
        )}
        {screen === 'assessment' && currentQuestionData && (
          <AssessmentScreen
            key="assessment"
            question={currentQuestionData}
            questionIndex={currentQuestion}
            totalQuestions={totalQuestions}
            progress={progress}
            selectedAnswer={currentAnswerIndex}
            onSelect={selectAnswer}
            onNext={next}
            onBack={back}
          />
        )}
        {screen === 'lead' && (
          <LeadCaptureScreen key="lead" onSubmit={submitLead} />
        )}
        {screen === 'results' && profile && (
          <ResultsScreen
            key="results"
            profile={profile}
            scores={scores}
            name={userInfo.name}
            onRestart={restart}
          />
        )}
      </AnimatePresence>
    </main>
  )
}

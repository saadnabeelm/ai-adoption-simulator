import { NextRequest, NextResponse } from 'next/server'

/**
 * GET /api/results
 *
 * Returns aggregated profile distribution data for the organisation dashboard.
 * Protected by an API key in production.
 *
 * Query params:
 *   ?org=acme           — filter by organisation (optional)
 *   ?from=2024-01-01    — date range start (optional)
 *   ?to=2024-12-31      — date range end (optional)
 *
 * Response:
 * {
 *   total: number
 *   profiles: { Explorer: number, Operator: number, Overwhelmed: number, Skeptic: number }
 *   topRole: string
 *   recentLeads: Lead[]
 * }
 */
export async function GET(req: NextRequest) {
  // ── Auth guard ────────────────────────────────────────────────────────────
  const apiKey = req.headers.get('x-api-key')
  if (process.env.DASHBOARD_API_KEY && apiKey !== process.env.DASHBOARD_API_KEY) {
    return NextResponse.json({ error: 'Unauthorized' }, { status: 401 })
  }

  // ── Mock data (replace with real DB query) ────────────────────────────────
  const mockData = {
    total: 248,
    profiles: {
      Explorer: 72,
      Operator: 81,
      Overwhelmed: 63,
      Skeptic: 32,
    },
    completionRate: 0.84,
    averageTimeSeconds: 247,
    topRoles: ['Marketing Manager', 'Product Manager', 'Operations Lead'],
    recentLeads: [
      { name: 'Alex P.', role: 'Head of Content', profile: 'Explorer', completedAt: new Date().toISOString() },
      { name: 'Jordan K.', role: 'Sales Director', profile: 'Operator', completedAt: new Date().toISOString() },
    ],
  }

  // ── Real DB query example (Supabase) ──────────────────────────────────────
  // const { org, from, to } = Object.fromEntries(req.nextUrl.searchParams)
  // const { data } = await supabase
  //   .from('leads')
  //   .select('profile, role, completed_at')
  //   .eq('org', org)
  //   .gte('completed_at', from)
  //   .lte('completed_at', to)

  return NextResponse.json(mockData, { status: 200 })
}

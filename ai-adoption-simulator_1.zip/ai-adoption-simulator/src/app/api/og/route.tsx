import { ImageResponse } from 'next/og'
import { NextRequest } from 'next/server'
import { PROFILES } from '@/config/profiles'
import { ProfileType } from '@/config/questions'

export const runtime = 'edge'

/**
 * GET /api/og?profile=Explorer&name=Alex
 *
 * Generates a dynamic Open Graph image for social sharing.
 * Use as the og:image meta tag on the results page.
 *
 * Add to ResultsScreen head:
 *   <meta property="og:image" content={`/api/og?profile=${profile}&name=${name}`} />
 */
export async function GET(req: NextRequest) {
  const { searchParams } = req.nextUrl
  const profileKey = (searchParams.get('profile') as ProfileType) || 'Explorer'
  const name = searchParams.get('name') || ''

  const p = PROFILES[profileKey] || PROFILES.Explorer
  const article = profileKey === 'Operator' || profileKey === 'Overwhelmed' ? 'an' : 'a'
  const displayName = name ? `${name} is` : "I'm"

  return new ImageResponse(
    (
      <div
        style={{
          width: '1200px',
          height: '630px',
          background: p.bgColor,
          display: 'flex',
          flexDirection: 'column',
          justifyContent: 'center',
          padding: '80px',
          fontFamily: 'serif',
        }}
      >
        <div style={{ fontSize: '20px', color: p.color, letterSpacing: '4px', textTransform: 'uppercase', marginBottom: '32px' }}>
          AI Adoption Simulator
        </div>
        <div style={{ fontSize: '72px', color: '#1A1814', lineHeight: '1.1', marginBottom: '24px' }}>
          {displayName} {article}{' '}
          <span style={{ color: p.color }}>{profileKey}</span>
        </div>
        <div style={{ fontSize: '28px', color: p.textColor, maxWidth: '700px', lineHeight: '1.5' }}>
          {p.theme}
        </div>
        <div style={{ position: 'absolute', bottom: '60px', right: '80px', fontSize: '18px', color: p.color }}>
          aiadoptionsimulator.com
        </div>
      </div>
    ),
    { width: 1200, height: 630 }
  )
}

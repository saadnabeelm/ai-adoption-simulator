import { NextRequest, NextResponse } from 'next/server'

/**
 * POST /api/leads
 *
 * Receives assessment results and user info.
 * Wire this up to your CRM, email provider, or database.
 *
 * Body shape:
 * {
 *   name: string
 *   email: string
 *   role: string
 *   profile: 'Explorer' | 'Operator' | 'Overwhelmed' | 'Skeptic'
 *   scores: { Explorer: number, Operator: number, Overwhelmed: number, Skeptic: number }
 *   answers: number[]
 *   completedAt: string (ISO)
 * }
 */
export async function POST(req: NextRequest) {
  try {
    const body = await req.json()
    const { name, email, role, profile, scores, answers, completedAt } = body

    // ── Validation ────────────────────────────────────────────────────────
    if (!name || !email || !role || !profile) {
      return NextResponse.json({ error: 'Missing required fields' }, { status: 400 })
    }
    if (!/^[^\s@]+@[^\s@]+\.[^\s@]+$/.test(email)) {
      return NextResponse.json({ error: 'Invalid email address' }, { status: 400 })
    }

    // ── Database (e.g. Supabase / Prisma / PlanetScale) ──────────────────
    // await db.leads.create({
    //   data: { name, email, role, profile, scores, answers, completedAt }
    // })

    // ── Email provider (e.g. Mailchimp) ──────────────────────────────────
    // await mailchimp.lists.addListMember(process.env.MAILCHIMP_LIST_ID!, {
    //   email_address: email,
    //   status: 'subscribed',
    //   merge_fields: { FNAME: name, ROLE: role, PROFILE: profile }
    // })

    // ── HubSpot CRM ───────────────────────────────────────────────────────
    // await hubspot.crm.contacts.basicApi.create({
    //   properties: { email, firstname: name, jobtitle: role, ai_profile: profile }
    // })

    // ── Webhook (Zapier / Make) ───────────────────────────────────────────
    // await fetch(process.env.WEBHOOK_URL!, {
    //   method: 'POST',
    //   headers: { 'Content-Type': 'application/json' },
    //   body: JSON.stringify({ name, email, role, profile, scores })
    // })

    console.log('Lead captured:', { name, email, role, profile, scores })

    return NextResponse.json({ success: true, profile }, { status: 200 })
  } catch (err) {
    console.error('Lead capture error:', err)
    return NextResponse.json({ error: 'Internal server error' }, { status: 500 })
  }
}

export type ProfileType = 'Explorer' | 'Operator' | 'Overwhelmed' | 'Skeptic'

export interface Answer {
  text: string
  profile: ProfileType
}

export interface Question {
  id: number
  question: string
  answers: Answer[]
}

export const QUESTIONS: Question[] = [
  {
    id: 1,
    question: 'How would you describe your current use of AI at work?',
    answers: [
      { text: "I'm experimenting here and there, but still figuring it out.", profile: 'Explorer' },
      { text: 'I use it regularly for certain tasks and it helps me work faster.', profile: 'Operator' },
      { text: 'I know it could help, but I feel unsure where to begin or how to use it well.', profile: 'Overwhelmed' },
      { text: "I rarely use it because I'm not convinced it adds much value to my work.", profile: 'Skeptic' },
    ],
  },
  {
    id: 2,
    question: 'When you think about AI in the workplace, what best describes your reaction?',
    answers: [
      { text: 'Curious — I want to understand how it could help me.', profile: 'Explorer' },
      { text: 'Practical — I mostly think about how it can save time.', profile: 'Operator' },
      { text: 'Overloaded — it feels like one more thing I'm supposed to learn.', profile: 'Overwhelmed' },
      { text: "Cautious — I'm not sure I trust it enough to rely on it.", profile: 'Skeptic' },
    ],
  },
  {
    id: 3,
    question: 'How confident do you feel writing a good prompt for an AI tool?',
    answers: [
      { text: 'Somewhat confident, but I still feel like I'm learning through trial and error.', profile: 'Explorer' },
      { text: 'Quite confident — I usually know how to get a useful result.', profile: 'Operator' },
      { text: "Not very confident — I often don't know what to ask or how to phrase it.", profile: 'Overwhelmed' },
      { text: "I haven't really tried enough to feel confident, or I avoid it.", profile: 'Skeptic' },
    ],
  },
  {
    id: 4,
    question: 'Which of these best reflects how you currently use AI?',
    answers: [
      { text: 'I use it occasionally to explore ideas or test possibilities.', profile: 'Explorer' },
      { text: 'I use it for recurring tasks like drafting, summarising, or organising work.', profile: 'Operator' },
      { text: 'I jump in and out, but my use feels inconsistent and unstructured.', profile: 'Overwhelmed' },
      { text: 'I generally prefer to do things myself rather than use AI.', profile: 'Skeptic' },
    ],
  },
  {
    id: 5,
    question: 'What is the biggest barrier stopping you from using AI more effectively?',
    answers: [
      { text: 'I need more guidance and examples to build confidence.', profile: 'Explorer' },
      { text: 'I want better workflows so I can use it more strategically.', profile: 'Operator' },
      { text: 'I do not know where it fits into my work in a simple, sustainable way.', profile: 'Overwhelmed' },
      { text: "I'm concerned it may reduce quality, trust, or authenticity.", profile: 'Skeptic' },
    ],
  },
  {
    id: 6,
    question: 'How relevant do you think AI is to your role?',
    answers: [
      { text: "It seems relevant, and I'd like to learn where it fits best.", profile: 'Explorer' },
      { text: 'It is already relevant and useful in parts of my workflow.', profile: 'Operator' },
      { text: 'It is probably relevant, but I have not translated that into practical habits yet.', profile: 'Overwhelmed' },
      { text: "I'm still not convinced it is particularly relevant to what I do.", profile: 'Skeptic' },
    ],
  },
  {
    id: 7,
    question: 'When AI gives you an output, what do you usually do next?',
    answers: [
      { text: 'I review it, learn from it, and test what else it can do.', profile: 'Explorer' },
      { text: 'I refine it quickly and use it as part of my workflow.', profile: 'Operator' },
      { text: "I often second-guess it or restart because I'm not sure if I'm using it properly.", profile: 'Overwhelmed' },
      { text: "I usually do not use the output because I don't trust it enough.", profile: 'Skeptic' },
    ],
  },
  {
    id: 8,
    question: 'Which statement sounds most like you?',
    answers: [
      { text: "I'm interested in AI, but I'm still in the discovery stage.", profile: 'Explorer' },
      { text: 'I treat AI as a useful assistant for getting work done.', profile: 'Operator' },
      { text: 'I feel like I should be using AI better than I currently am.', profile: 'Overwhelmed' },
      { text: 'I think AI is overhyped for most workplace use cases.', profile: 'Skeptic' },
    ],
  },
  {
    id: 9,
    question: 'How often do you use AI tools in a normal work week?',
    answers: [
      { text: 'Once or twice, mainly to experiment or explore.', profile: 'Explorer' },
      { text: 'Several times a week as part of how I get work done.', profile: 'Operator' },
      { text: 'Inconsistently — I use it sometimes, then stop, then return to it.', profile: 'Overwhelmed' },
      { text: 'Rarely or never.', profile: 'Skeptic' },
    ],
  },
  {
    id: 10,
    question: 'What would help you most right now with AI at work?',
    answers: [
      { text: 'A clearer starting point and a few practical ways to begin.', profile: 'Explorer' },
      { text: 'Better systems and prompts to improve how I already use it.', profile: 'Operator' },
      { text: 'Simplicity — I need less noise and more clarity on what actually matters.', profile: 'Overwhelmed' },
      { text: 'Evidence that it can genuinely improve my work without compromising quality.', profile: 'Skeptic' },
    ],
  },
  {
    id: 11,
    question: 'How do you see AI affecting your professional role?',
    answers: [
      { text: 'It feels like an opportunity to learn and evolve.', profile: 'Explorer' },
      { text: 'It feels like a tool that can improve efficiency and output.', profile: 'Operator' },
      { text: 'It feels important, but also a bit mentally demanding to keep up with.', profile: 'Overwhelmed' },
      { text: "It feels uncertain, and I'm wary of becoming too dependent on it.", profile: 'Skeptic' },
    ],
  },
  {
    id: 12,
    question: 'Which best describes your next step with AI?',
    answers: [
      { text: 'Keep exploring and build confidence through small experiments.', profile: 'Explorer' },
      { text: 'Improve and systemise how I already use it in my workflow.', profile: 'Operator' },
      { text: 'Reduce overwhelm and get clear on a practical, sustainable approach.', profile: 'Overwhelmed' },
      { text: 'Take more time to evaluate whether it is actually worth adopting.', profile: 'Skeptic' },
    ],
  },
]

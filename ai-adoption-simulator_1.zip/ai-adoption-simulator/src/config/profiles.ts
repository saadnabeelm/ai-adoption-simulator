import { ProfileType } from './questions'

export interface Profile {
  name: ProfileType
  theme: string
  summary: string
  description: string
  strengths: string[]
  challenges: string[]
  nextStep: string
  ctaLine: string
  color: string
  bgColor: string
  textColor: string
}

export const PROFILES: Record<ProfileType, Profile> = {
  Explorer: {
    name: 'Explorer',
    theme: 'Curious but early',
    summary: "You're open to AI and ready to learn, but you're still building confidence and consistency.",
    description:
      "You see the potential of AI and you're curious about where it fits. You're likely in the early experimentation stage — trying things out, testing ideas, and learning what works. The opportunity for you is not motivation. It's momentum. With a few practical workflows and clearer use cases, you could move from occasional experimentation to confident everyday use.",
    strengths: ['Open-minded and curious', 'Willing to experiment', 'Ready to build new habits'],
    challenges: [
      'Inconsistent use',
      'Limited confidence with prompting',
      'Still translating interest into routine practice',
    ],
    nextStep:
      'Start with 2–3 repeatable use cases in your actual work, such as drafting emails, summarising meetings, or brainstorming ideas.',
    ctaLine: "You don't need to master AI all at once. You just need a better starting point.",
    color: '#2D5BE3',
    bgColor: '#EEF2FF',
    textColor: '#1A3BAA',
  },
  Operator: {
    name: 'Operator',
    theme: 'Active but tactical',
    summary: "You're already using AI to get work done, but there's room to use it more strategically.",
    description:
      "You're beyond the awareness stage. AI is already part of how you work, especially for speed, drafting, and practical support. That's a strong position. Your next step is to move from tactical use to more intentional integration — building better workflows, prompting more effectively, and using AI not just to save time, but to improve thinking and decision-making.",
    strengths: ['Action-oriented', 'Comfortable using AI', 'Already seeing practical value'],
    challenges: [
      'May rely on AI tactically rather than strategically',
      'Could benefit from better systems and prompt design',
      'May not yet be using AI for deeper thinking',
    ],
    nextStep: 'Audit the tasks you repeat most often and build a simple AI-assisted workflow around them.',
    ctaLine: "You're already using AI. Now it's time to use it with more intention.",
    color: '#0F6E56',
    bgColor: '#E1F5EE',
    textColor: '#085041',
  },
  Overwhelmed: {
    name: 'Overwhelmed',
    theme: 'Interested but overloaded',
    summary: "You can see the value of AI, but uncertainty and overload are getting in the way of confident action.",
    description:
      "You're not closed off to AI — far from it. In fact, part of the frustration may be that you know it matters. The challenge is that it feels noisy, unclear, or mentally demanding to figure out where to begin. You likely do not need more information. You need less friction. The right next step is a simpler, more grounded approach that connects AI to a few practical moments in your existing workflow.",
    strengths: ['Aware that AI matters', 'Motivated to improve', 'Likely more ready than you think'],
    challenges: [
      'Unclear starting point',
      'Cognitive overload',
      'Low confidence and inconsistent follow-through',
    ],
    nextStep: 'Ignore the hype. Pick one recurring task and learn one reliable AI workflow for it.',
    ctaLine: 'You do not need to do more. You need a simpler way in.',
    color: '#BA7517',
    bgColor: '#FAEEDA',
    textColor: '#854F0B',
  },
  Skeptic: {
    name: 'Skeptic',
    theme: 'Resistant or unconvinced',
    summary: "You're cautious about AI and not yet convinced it improves your work in a meaningful way.",
    description:
      "Your hesitation is not necessarily a bad thing. In many workplaces, skepticism reflects care about quality, trust, and professional standards. You're likely asking valid questions: Is this useful? Is it reliable? Is it worth the effort? The goal is not to force adoption. It's to test whether AI can support your work in ways that still feel credible, thoughtful, and aligned with how you want to operate.",
    strengths: ['Thoughtful and discerning', 'Protective of quality and standards', "Less likely to adopt tools blindly"],
    challenges: [
      'Low experimentation',
      'Limited trust in outputs',
      'May miss practical opportunities because of early resistance',
    ],
    nextStep:
      'Test AI in one low-risk area where quality can be easily reviewed, such as summarising notes or generating first-draft ideas.',
    ctaLine: 'You do not have to buy the hype. You just need enough evidence to make your own decision.',
    color: '#993556',
    bgColor: '#FBEAF0',
    textColor: '#72243E',
  },
}

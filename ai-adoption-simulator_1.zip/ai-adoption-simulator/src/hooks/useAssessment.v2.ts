'use client'

import { useState, useCallback } from 'react'
import { QUESTIONS, ProfileType } from '@/config/questions'
import { INITIAL_SCORES, Scores, addScore, removeScore, calculateDominantProfile } from '@/lib/scoring'
import { saveResult, clearResult } from '@/lib/storage'
import {
  trackAssessmentStarted,
  trackQuestionAnswered,
  trackAssessmentCompleted,
  trackLeadCaptured,
} from '@/lib/analytics'

export type Screen = 'landing' | 'assessment' | 'lead' | 'results'

export interface UserInfo {
  name: string
  email: string
  role: string
}

export function useAssessment() {
  const [screen, setScreen] = useState<Screen>('landing')
  const [currentQuestion, setCurrentQuestion] = useState(0)
  const [selectedAnswers, setSelectedAnswers] = useState<number[]>([])
  const [scores, setScores] = useState<Scores>(INITIAL_SCORES)
  const [profile, setProfile] = useState<ProfileType | null>(null)
  const [userInfo, setUserInfo] = useState<UserInfo>({ name: '', email: '', role: '' })
  const [completedAt, setCompletedAt] = useState<string>('')

  const start = useCallback(() => {
    trackAssessmentStarted()
    setScreen('assessment')
    setCurrentQuestion(0)
    setSelectedAnswers([])
    setScores(INITIAL_SCORES)
    setProfile(null)
    setCompletedAt('')
    clearResult()
  }, [])

  const selectAnswer = useCallback(
    (answerIndex: number) => {
      setSelectedAnswers((prev) => {
        const next = [...prev]
        next[currentQuestion] = answerIndex
        return next
      })
    },
    [currentQuestion]
  )

  const next = useCallback(() => {
    const answerIdx = selectedAnswers[currentQuestion]
    if (answerIdx === undefined) return

    const profileForAnswer = QUESTIONS[currentQuestion].answers[answerIdx].profile
    trackQuestionAnswered(currentQuestion + 1, profileForAnswer)

    const newScores = addScore(scores, profileForAnswer)
    setScores(newScores)

    if (currentQuestion < QUESTIONS.length - 1) {
      setCurrentQuestion((q) => q + 1)
    } else {
      trackAssessmentCompleted(newScores)
      setScreen('lead')
    }
  }, [currentQuestion, selectedAnswers, scores])

  const back = useCallback(() => {
    if (currentQuestion === 0) return

    const prevAnswerIdx = selectedAnswers[currentQuestion - 1]
    if (prevAnswerIdx !== undefined) {
      const prevProfile = QUESTIONS[currentQuestion - 1].answers[prevAnswerIdx].profile
      setScores((prev) => removeScore(prev, prevProfile))
    }
    setCurrentQuestion((q) => q - 1)
  }, [currentQuestion, selectedAnswers])

  const submitLead = useCallback(
    (info: UserInfo) => {
      trackLeadCaptured(info.role)
      setUserInfo(info)

      const dominant = calculateDominantProfile(scores)
      setProfile(dominant)

      const now = new Date().toISOString()
      setCompletedAt(now)

      saveResult({
        profile: dominant,
        scores,
        name: info.name,
        email: info.email,
        role: info.role,
        answers: selectedAnswers,
        completedAt: now,
      })

      // Fire-and-forget to backend API
      fetch('/api/leads', {
        method: 'POST',
        headers: { 'Content-Type': 'application/json' },
        body: JSON.stringify({
          name: info.name,
          email: info.email,
          role: info.role,
          profile: dominant,
          scores,
          answers: selectedAnswers,
          completedAt: now,
        }),
      }).catch(() => {
        // Graceful failure — result is already saved to localStorage
      })

      setScreen('results')
    },
    [scores, selectedAnswers]
  )

  const restart = useCallback(() => {
    setScreen('landing')
    setCurrentQuestion(0)
    setSelectedAnswers([])
    setScores(INITIAL_SCORES)
    setProfile(null)
    setUserInfo({ name: '', email: '', role: '' })
    setCompletedAt('')
    clearResult()
  }, [])

  return {
    screen,
    currentQuestion,
    selectedAnswers,
    scores,
    profile,
    userInfo,
    completedAt,
    totalQuestions: QUESTIONS.length,
    currentQuestionData: QUESTIONS[currentQuestion],
    currentAnswerIndex: selectedAnswers[currentQuestion] ?? null,
    progress: ((currentQuestion + 1) / QUESTIONS.length) * 100,
    start,
    selectAnswer,
    next,
    back,
    submitLead,
    restart,
  }
}

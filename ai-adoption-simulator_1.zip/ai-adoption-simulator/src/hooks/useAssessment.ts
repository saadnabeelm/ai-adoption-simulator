'use client'

import { useState, useCallback } from 'react'
import { QUESTIONS, ProfileType } from '@/config/questions'
import { INITIAL_SCORES, Scores, addScore, removeScore, calculateDominantProfile } from '@/lib/scoring'
import { saveResult, clearResult } from '@/lib/storage'

export type Screen = 'landing' | 'assessment' | 'lead' | 'results'

export interface UserInfo {
  name: string
  email: string
  role: string
}

export function useAssessment() {
  const [screen, setScreen] = useState<Screen>('landing')
  const [currentQuestion, setCurrentQuestion] = useState(0)
  const [selectedAnswers, setSelectedAnswers] = useState<number[]>([])
  const [scores, setScores] = useState<Scores>(INITIAL_SCORES)
  const [profile, setProfile] = useState<ProfileType | null>(null)
  const [userInfo, setUserInfo] = useState<UserInfo>({ name: '', email: '', role: '' })

  const start = useCallback(() => {
    setScreen('assessment')
    setCurrentQuestion(0)
    setSelectedAnswers([])
    setScores(INITIAL_SCORES)
    setProfile(null)
    clearResult()
  }, [])

  const selectAnswer = useCallback((answerIndex: number) => {
    setSelectedAnswers((prev) => {
      const next = [...prev]
      next[currentQuestion] = answerIndex
      return next
    })
  }, [currentQuestion])

  const next = useCallback(() => {
    const answerIdx = selectedAnswers[currentQuestion]
    if (answerIdx === undefined) return

    const profileForAnswer = QUESTIONS[currentQuestion].answers[answerIdx].profile
    setScores((prev) => addScore(prev, profileForAnswer))

    if (currentQuestion < QUESTIONS.length - 1) {
      setCurrentQuestion((q) => q + 1)
    } else {
      setScreen('lead')
    }
  }, [currentQuestion, selectedAnswers])

  const back = useCallback(() => {
    if (currentQuestion === 0) return

    const prevAnswerIdx = selectedAnswers[currentQuestion - 1]
    if (prevAnswerIdx !== undefined) {
      const prevProfile = QUESTIONS[currentQuestion - 1].answers[prevAnswerIdx].profile
      setScores((prev) => removeScore(prev, prevProfile))
    }
    setCurrentQuestion((q) => q - 1)
  }, [currentQuestion, selectedAnswers])

  const submitLead = useCallback(
    (info: UserInfo) => {
      setUserInfo(info)
      const dominant = calculateDominantProfile(scores)
      setProfile(dominant)

      saveResult({
        profile: dominant,
        scores,
        name: info.name,
        email: info.email,
        role: info.role,
        answers: selectedAnswers,
        completedAt: new Date().toISOString(),
      })

      setScreen('results')
    },
    [scores, selectedAnswers]
  )

  const restart = useCallback(() => {
    setScreen('landing')
    setCurrentQuestion(0)
    setSelectedAnswers([])
    setScores(INITIAL_SCORES)
    setProfile(null)
    setUserInfo({ name: '', email: '', role: '' })
    clearResult()
  }, [])

  return {
    screen,
    currentQuestion,
    selectedAnswers,
    scores,
    profile,
    userInfo,
    totalQuestions: QUESTIONS.length,
    currentQuestionData: QUESTIONS[currentQuestion],
    currentAnswerIndex: selectedAnswers[currentQuestion] ?? null,
    progress: ((currentQuestion + 1) / QUESTIONS.length) * 100,
    start,
    selectAnswer,
    next,
    back,
    submitLead,
    restart,
  }
}
